﻿// ---------------------------------------------------------------------------

#pragma hdrstop
#include <algorithm>
#include "pomocna.h"

bool operator < (Tacka A, Tacka B) {
	if (A.x < B.x)
		return true;
	if (A.x == B.x)
		return A.y < B.y;
	return false;
}

bool operator == (Tacka A, Tacka B) {
	return A.x == B.x && A.y == B.y;
}

int Orijentacija(Tacka A, Tacka B, Tacka C) {

	int P = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y);
	if (P > 0)
		return -1;
	if (P < 0)
		return 1;
	return 0;

}

Tacka srednjaTacka(Duz a) {
	Tacka srednja;
	srednja.x = (a.pocetna.x + a.krajnja.x) / 2;
	srednja.y = (a.pocetna.y + a.krajnja.y) / 2;
	return srednja;
}


bool operator < (Duz a, Duz b) {
	if (a.pocetna < b.pocetna && a.krajnja < b.krajnja)
		return true;
	return false;
}

double xKor(Tacka, Tacka, Tacka);

bool manji(Duz a, Duz b) {
	// ukoliko je riječ o dužima s različitim y koordinatama ( slucaj kada gledam duz i tacku )
	// a kada trazim susjedne duzi od tacke sa slike, tada sam tacku posmatrala kao duz 2 iste tacke
	// pa se ovdje gleda koja ima manju x koordinatu, tj. tada ta tacka ima x koordinatu vrijednosti
	// izmedju 2 vrijednosti pocetne i krajnje tacke (x koordinate) , te duzi

	if(Orijentacija(a.pocetna,a.krajnja,srednjaTacka(b)) == -1 ) return true;

	return false;
}
 // ove dvije funkcije - manji() i veći()
 // koristim za poređenje duži pri pronalasku dvije susjedne duži od tačke sa slike
bool veci(Duz a, Duz b) {
	if(Orijentacija(a.pocetna,a.krajnja,srednjaTacka(b)) == 1 ) return true;

	return false;
}

bool operator > (Duz a, Duz b) {
	if (b.pocetna < a.pocetna && b.krajnja < a.krajnja)
		return true;
	return false;
}


bool operator == (Duz a, Duz b) {
	return (!(a < b) && !(a > b));
}

bool daLiJeTackaUnutarTrougla(Tacka P, Trougao t) {
	if (Orijentacija(t.A, t.B, P) == Orijentacija(t.B, t.C, P) && Orijentacija
		(t.B, t.C, P) == Orijentacija(t.C, t.A, P))
		return true;
	return false;
}

// Stablo


// funkcija koja za određeni čvor vraća visinu na kojoj se taj isti
int visina(Stablo::Cvor * cvor) {
	if (cvor == nullptr)
		return 0;
	return cvor->visina;
}

// lijeva rotacija - p->dd postaje srednji čvor, p postane lijevo dijete
void lRotacija(Stablo::Cvor* &p) {
	Stablo::Cvor* dijete;
	dijete = p->dd;
	p->dd = dijete->ld;
	dijete->ld = p;
	p = dijete;

	p->visina = max(visina(p->ld), visina(p->dd)) + 1;
	dijete->visina = max(visina(p->ld), visina(p->dd)) + 1;

}

// desna rotacija - p->ld postaje srednji čvor, p postane desno dijete
void rRotacija(Stablo::Cvor* &p) {

	Stablo::Cvor* dijete;
	dijete = p->ld;
	p->ld = dijete->dd;
	dijete->dd = p;
	p = dijete;

	dijete->visina = max(visina(dijete->ld), visina(dijete->ld)) + 1;
	p->visina = max(visina(p->ld), visina(p->dd)) + 1;

}

// vraća balans od trenutnog čvora, u zavisnosti od vrijednosti, vrše se rotacije
// 0  - balansirano stablo
// <0 - desni čvor ima veću visinu od lijevog
// >0 - lijevi čvor ima veću visinu od desnog
int balansiraj(Stablo::Cvor *cvor) {
	if (cvor == nullptr)
		return 0;
	return visina(cvor->ld) - visina(cvor->dd);
}

// Rekurzivna funkcija za ubacivanje duži u
// Avl stablo, koje se pritom balansira pomoću visine

void Stablo::umetni(Cvor* &cvor, Duz duz) {

	// bazni slučaj -  ubacuje se na prvo pronađeno mjesto
	if (cvor == nullptr)
		cvor = new Cvor(duz);

	// ukoliko je duž manja, tj.lijevo se nalazi od duži na trenutnom čvoru ,
	// data duž se ubacuje u lijevo podstablo od tog trenutnog čvora
	if (duz < cvor->duz)
		umetni(cvor->ld, duz);
	// inače, ukoliko je veća, tj. ukoliko se nalazi s desne strane duži trenutnog čvora,
	// data duž se ubacuje u desno podstablo od tog trenutnog čvora
	else if (duz > cvor->duz)
		umetni(cvor->dd, duz);
	// ne mogu u balansiranom stablu biti dvije duži koje imaju presjek
	// ili koje su identične pa taj slučaj ni ne posmatram


	// ažurira se visina trenutnog čvora nakon ubacivanja
	cvor->visina = 1 + max(visina(cvor->ld), visina(cvor->dd));

	// Uzme se balans od trenutnog čvora te ukoliko nije jednak nuli,
	// onda će doći do potrebnih rotacija
	int balans = balansiraj(cvor);

	// Postoje četiri slučaja nebalansiranog trenutnog čvora

	// l l rotacija
	// veća visina od lijevog djeteta,
	//data duž je manja od one na lijevom čvoru ,
	//tada taj lijevi čvor postane trenutni čvor ( desna rotacija)
	if (balans > 1 && duz < cvor->ld->duz)
		return rRotacija(cvor);

	// d d rotacija
	 //veća visina od desnog djeteta,
	// data duž je veća od one na desnom čvoru ,
	//tada taj desni čvor  postane trenutni čvor ( lijeva rotacija)
	if (balans < -1 && duz > cvor->dd->duz)
		return lRotacija(cvor);

	//  l d rotacija
	// veća visina od lijevog djeteta,
	// data duž veća od one na lijevom čvoru ,
	//  prvo se uradi lijeva rotacija od lijevog djeteta pa desna rotacija od trenutnog čvora
	if (balans > 1 && duz > cvor->ld->duz) {
		lRotacija(cvor->ld);
		return rRotacija(cvor);
	}

	//  d l rotacija
	// veća visina od desnog djeteta,
	// data duž manja od one na desnom čvoru ,
	//  prvo se uradi desna rotacija od desnog djeteta pa lijeva rotacija od trenutnog čvora
	if (balans < -1 && duz < cvor->dd->duz) {
		rRotacija(cvor->dd);
		return lRotacija(cvor);
	}


	// inače je balansirano stablo (balans = 0)
	return;
}


double k(Tacka a, Tacka b) {
	if (a.x != b.x)
		return (double)((a.y - b.y)) / ((double)(a.x - b.x));
	else
		return (double)((a.y - b.y)) / 0.001;

}

double l(Tacka a, Tacka b) {
	return ((double)a.y - k(a, b) * a.x);
}

// x koordinata tačke na duži ab, koja ima jednaku y koordinatu kao tačka c
double xKor(Tacka a, Tacka b, Tacka c) {
	double xk = ((double)c.y - l(a, b)) / k(a, b);
	return (xk);
}

// udaljenost početne tačke duži b od duži a  -
// slučaj kad posmatram pritisnutu tačku i njene susjedne duži - posmatram kao duž tu tačku
// xKor od duži a ima istu y koordinatu kao i b pa se gledaju samo x koordinate
int razlika(Duz a, Duz b) {
	return abs(xKor(a.pocetna, a.krajnja, b.pocetna) - b.pocetna.x);
}


// funkcija koja pronalazi prvu manju duž od zadane duži (maksimalna manja od duži)
void Stablo::maksimalniMinimum(Duz t, Cvor * trenutni, int &minUdaljenost,
	Cvor* &duzMiniUdaljenost) {

	// ukoliko više nema čvorova za pretragu, staje sa radom
	if (trenutni == nullptr)
		return;

	
	// ažuriranje minimalne udaljenosti , provjerava se je li trenutna duž bliža zadanoj od prethodne
	if (minUdaljenost > razlika(trenutni->duz, t) >
		0 && manji(trenutni->duz,t)) {
		minUdaljenost = razlika(trenutni->duz, t);
		duzMiniUdaljenost = trenutni;
	}

	// ukoliko je zadana duž na trenutnoj poziciji manja od zadane duži ,
	// posmatra se desno podstablo od tog trenutnog čvora
	if (manji(trenutni->duz , t))
		maksimalniMinimum(t, trenutni->dd, minUdaljenost, duzMiniUdaljenost);
	// inače se posmatra lijevo podstablo od trenutnog čvora
	else
		maksimalniMinimum(t, trenutni->ld, minUdaljenost, duzMiniUdaljenost);

}

// funkcija koja  pronalazi prvu veću duž do zadane duži (maksimalna manja od duži)
// radi na sličan način kao i funkcija Mini, vrijeme izvršavanja im je isto
// O(visina stabla) = O (log n) - jer je riječ o balansiranom stablu
void Stablo::minimalniMaksimum(Duz t, Cvor * trenutni, int &minUdaljenost,
	Cvor* &duzMiniUdaljenost) {

	// ukoliko više nema čvorova za pretražiti,data funkcija staje s radom funkcija
	if (trenutni == nullptr)
		return;

	if (minUdaljenost > razlika(trenutni->duz, t) > 0 && veci(trenutni->duz ,t ))
	{
		minUdaljenost = razlika(trenutni->duz, t);
		duzMiniUdaljenost = trenutni;
	}

	if (veci(trenutni->duz ,t))
		minimalniMaksimum(t, trenutni->ld, minUdaljenost, duzMiniUdaljenost);
	else
		minimalniMaksimum(t, trenutni->dd, minUdaljenost, duzMiniUdaljenost);

}

// klasična pretraga u stablu, idem kroz stablo sve dok postoje čvorovi
// te se gleda je li duž veća ili manja od one na trenutnoj poziciji
Stablo::Cvor* Stablo::pretraga(Duz duz) {
	Cvor *trenutni = korijen;
	while (trenutni != nullptr) {
		if (duz == trenutni->duz)
			return trenutni;
		else if (duz > trenutni->duz)
			trenutni = trenutni->dd;
		else
			trenutni = trenutni->ld;

	}
	return nullptr;
}

// funkcija koja nađe prvu veću duž, tj. najbližu desnu duž od tačke
Stablo::Cvor* Stablo::desnaDuz(Stablo::Cvor * trenutni, Tacka t) {
	Duz target(t, t);
	// minimalna udaljenost se inicijalizira na početku u maksimalnu
	int minUdaljenost = INT_MAX;
	Cvor* duzMiniUdaljenost;

	// Nadje se najbliži čvor u stablu desno od tačke
	// tačku pretvorim u duž 2 iste tačke
	minimalniMaksimum(target, trenutni, minUdaljenost, duzMiniUdaljenost);

	return duzMiniUdaljenost;

}

// funkcija koja nađe prvu manju duž, tj. najbližu lijevu duž od tačke
Stablo::Cvor* Stablo::lijevaDuz(Stablo::Cvor * trenutni, Tacka t) {
	Duz target(t, t);
	// minimalna udaljenost se inicijalizira na početku u maksimalnu
	int minUdaljenost = INT_MAX;
	Cvor* duzMiniUdaljenost;

	// // Nadje se najbliži čvor u stablu lijevo od tačke
	maksimalniMinimum(target, trenutni, minUdaljenost, duzMiniUdaljenost);

	return duzMiniUdaljenost;
}

// funkcija pomoću koje se nađe segment u kojem se tačka nalazi
// složenost je O(2*logn) = O(log n) - nađem susjednu desnu i lijevu duž 2 * O(logn)
pair<Stablo::Cvor, Stablo::Cvor>Stablo::NadjiT(Tacka t, Cvor * korijen,
	Stablo &s) {
	Cvor *desni = desnaDuz(korijen, t);
	Cvor * lijevi = lijevaDuz(korijen, t);
	return {*lijevi, *desni};
}

// -----------------------------------------------------------------------
#pragma package(smart_init)
