//---------------------------------------------------------------------------

#ifndef pomocnaH
#define pomocnaH
#include <vector>
using namespace std;

struct Tacka {
	int x;
	int y;
	Tacka():x(0),y(0) {}
	Tacka(int X, int Y):x(X),y(Y) {}
    void Crtaj(TImage*) const;
};

bool operator==(Tacka,Tacka);
bool operator<(Tacka,Tacka);

struct Duz {
	Tacka pocetna;
	Tacka krajnja;
	Duz():pocetna(),krajnja(){}
	Duz(Tacka A,Tacka B):pocetna(A),krajnja(B) { if(krajnja < pocetna)
												  swap(pocetna,krajnja);
                                                  if(pocetna.y < krajnja.y) swap(pocetna,krajnja);
											   }
	void Crtaj(TImage*) const;
};

struct Trougao {
	Tacka A;
	Tacka B;
	Tacka C;
	Trougao(Tacka A, Tacka B, Tacka C):A(A),B(B),C(C) {}
	void Crtaj(TImage*) const;
};


bool operator<(Duz,Duz);


class Stablo {

	public:
	  struct Cvor {
			Duz duz;
			int visina;
			Cvor *rod, *ld, *dd;
			Cvor(Duz duz , int visina = 0, Cvor *rod = nullptr, Cvor *ld = nullptr,
			   Cvor *dd = nullptr):duz(duz),visina(visina) ,rod(rod),ld(ld),dd(dd) {}
			Cvor(Cvor *rod = nullptr, Cvor *ld = nullptr,Cvor *dd = nullptr):duz(),visina(0),rod(rod),ld(ld),dd(dd){}
	  };
	  private:
		Cvor *korijen;
		void umetni(Cvor* &, Duz );
		pair<Cvor,Cvor> NadjiT(Tacka t, Cvor * cvor,Stablo &s);
		void maksimalniMinimum( Duz ,Cvor * trenutni, int &, Cvor* &);
		void minimalniMaksimum( Duz ,Cvor * trenutni, int &, Cvor* &);;


  public:
  Stablo() : korijen() {korijen = nullptr;}
  Stablo(Cvor *pok) {Stablo::korijen = pok;}
  Cvor * getKorijen() { return korijen;}
  void  umetni(Duz duz) { umetni(korijen ,duz);}
  pair<Cvor,Cvor> NadjiT(Tacka t,Stablo &s){ return NadjiT(t,korijen,s);}
  Cvor* desnaDuz(Cvor * trenutni,Tacka t) ;
  Cvor* lijevaDuz(Cvor * trenutni,Tacka t) ;
  Cvor* pretraga(Duz duz);
 };


int Orijentacija(Tacka,Tacka,Tacka);
bool daLiJeTackaUnutarTrougla(Tacka,Trougao);



//---------------------------------------------------------------------------
#endif
