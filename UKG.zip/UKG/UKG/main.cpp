﻿ //---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include <algorithm>
#include <vector>
using namespace std;
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForma *Forma;
Stablo stablo;
bool duziDodane = false;
int Ygornja,Ydonja;

//---------------------------------------------------------------------------
__fastcall TForma::TForma(TComponent* Owner)
	: TForm(Owner)
{
		Slika->Canvas->FillRect(Rect(0,0,Slika->Width,Slika->Height));
	  
}
//---------------------------------------------------------------------------
void TForma::dodajTacku(Tacka nova) {
	tacke.push_back(nova);

}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

void __fastcall TForma::SlikaMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y)
{

	// duži se dodaju jedna po jedna (dvije po dvije tačke)
	// sortirala sam tako da početna tačka duži uvijek bude donja
	// sve dok se ne pritisne dugme Finish, dodaju se duži u stablo
	if(DodavanjeDuži->Checked) {
			Tacka nova(X,Y);


		if(!duziDodane) {
			if(tacke.size() == 0) dodajTacku(nova);
			else {
				dodajTacku(nova);
				Duz novaD(tacke[0],tacke[1]);
				novaD.pocetna.y = Ydonja;
				novaD.krajnja.y = Ygornja;
				Slika->Canvas->Pen->Color = static_cast<TColor>(RGB(8, 72, 94));
				Slika->Canvas->MoveTo(novaD.pocetna.x,novaD.pocetna.y);
				Slika->Canvas->LineTo(novaD.krajnja.x,novaD.krajnja.y);
				stablo.umetni(novaD);

				//nakon što se doda duž u stablo, isprazni se vektor
				// tako sam sigurna da dvije duži neće imati presjeka ( iste gornje ili donje tačke)
				tacke.clear();

			}
		}
	   if(duziDodane) {

			Tacka t(X,Y);
			 //ukoliko se pritisne neka tačka u prostoru oko dvije horizontalne duži, ispiše se poruka
			if(Y > Ydonja || Y < Ygornja) ShowMessage("Van segmenata");
			else {

				// u suprotnom nadju se dvije najbliže duži od pritisnute tačke
				pair<Stablo::Cvor,Stablo::Cvor> cvor = stablo.NadjiT(t,stablo);

				// Oboji se to područje oko tačke
				TPoint tackePoligona[5];
				tackePoligona[0] = Point(cvor.first.duz.pocetna.x,Ydonja);
				tackePoligona[1] = Point(cvor.first.duz.krajnja.x,Ygornja);
				tackePoligona[2] = Point(cvor.second.duz.krajnja.x,Ygornja);
				tackePoligona[3] = Point(cvor.second.duz.pocetna.x,Ydonja);
				tackePoligona[4] = Point(cvor.first.duz.pocetna.x,Ydonja);
				Slika->Canvas->Brush->Color = static_cast<TColor>(RGB(175, 192, 210));
				Slika->Canvas->Polygon(tackePoligona, 4);
				}
	   }
	}

}

//---------------------------------------------------------------------------

void __fastcall TForma::SlikaMouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
    EditKoordinate->Text = "( " + IntToStr(X) + " , " + IntToStr(Y) + " )";
}
//---------------------------------------------------------------------------

void __fastcall TForma::OKClick(TObject *Sender)
{
	//kada se pritisne OK dugme, preuzmu se vrijednosti koje će biti horizontalne duži ;
	// ukoliko se slučajno unesu pogrešno duži ( jer je drukčije postavljen koordinatni sistem ovdje)
	// zamijenim ih te opet budu ispravno poredane
	Ygornja = gornjaDuz->Text.ToInt();
	Ydonja = donjaDuz->Text.ToInt();
	if (Ydonja < Ygornja) swap(Ydonja,Ygornja);
	Slika->Canvas->Pen->Color = static_cast<TColor>(RGB(8, 72, 94));
	Slika->Canvas->MoveTo(0,Ydonja);
	Slika->Canvas->LineTo(1000,Ydonja);
	Slika->Canvas->MoveTo(0,Ygornja);
	Slika->Canvas-> LineTo(1000,Ygornja);



}




//---------------------------------------------------------------------------



void __fastcall TForma::FinishClick(TObject *Sender)
{
	// kad se pritisne na finish dugme ,
	// postavi se vrijednost duziDodane na tačno
	// dodam najmanju i najveću duž u stablo ( jer se dijeli prostor na n+1 dijelova
	//pa se uključe i prva i druga duž tog pravougaonika)
	duziDodane = true;
	stablo.umetni(Duz(Tacka(0,Ydonja),Tacka(0,Ygornja)));
	stablo.umetni(Duz(Tacka(1000,Ydonja),Tacka(1000,Ygornja)));
	Slika->Canvas->Pen->Color = static_cast<TColor>(RGB(8, 72, 94));
	Slika->Canvas->MoveTo(0,Ydonja);
	Slika->Canvas->LineTo(0,Ygornja);
	Slika->Canvas->MoveTo(1000,Ydonja);
	Slika->Canvas->LineTo(1000,Ygornja);
}
//---------------------------------------------------------------------------






