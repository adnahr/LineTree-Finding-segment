//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include "pomocna.h"
#include <vector>

using namespace std;
//---------------------------------------------------------------------------
class TForma : public TForm
{
__published:	// IDE-managed Components
	TImage *Slika;
	TLabel *LabelKoordinate;
	TEdit *EditKoordinate;
	TLabel *Label1;
	TLabel *Label2;
	TButton *OK;
	TEdit *donjaDuz;
	TEdit *gornjaDuz;
	TRadioButton *DodavanjeDu�i;
	TButton *Finish;

	void __fastcall SlikaMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall SlikaMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y);
	void __fastcall OKClick(TObject *Sender);
	void __fastcall FinishClick(TObject *Sender);



private:
	vector<Tacka> tacke;
    vector<Tacka> v;
    vector<Tacka> konveksni_omotac;
	void dodajTacku(Tacka);
	bool zavrsenProstiMnogougao;
	bool zavrsenKonveksniOmotac;
	bool daLiJeUnutarKonveksnog(Tacka);
    void povuciTangente(Tacka);
public:
	__fastcall TForma(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForma *Forma;
//---------------------------------------------------------------------------
#endif
